# LZtimer
静态网站源码；运行 python3 -m http.server 8765 后访问 http://localhost:8765/ 。上传所有文件到静态托管服务即可发布。需要联网加载 CDN 依赖。成绩保存在各浏览器 localStorage 中。